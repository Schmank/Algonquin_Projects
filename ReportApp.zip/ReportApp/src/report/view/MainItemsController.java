package report.view;

import java.io.IOException;

import javafx.fxml.FXML;
import report.Main;

public class MainItemsController {
	private Main main;

	@FXML
	private void getInventory() throws IOException{
		main.showInventoryScene();

	}
	@FXML
	private void getSales() throws IOException{
		main.showSalesScene();

	}
}
