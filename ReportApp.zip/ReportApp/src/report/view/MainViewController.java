package report.view;

import java.io.IOException;

import javafx.fxml.FXML;
import report.Main;

public class MainViewController {
	private Main main;

	@FXML
	private void goHome() throws IOException{
		main.showMainItems();

	}
}
